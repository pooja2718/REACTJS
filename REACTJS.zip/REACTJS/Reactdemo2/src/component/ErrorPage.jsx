import React from 'react';

const ErrorPage = () => {
  return (
    <div className="container">
      <h1>404 - Page Not Found</h1>
    </div>
  )
}

export default ErrorPage