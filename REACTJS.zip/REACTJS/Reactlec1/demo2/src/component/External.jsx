import React from 'react'
import './style.css'

const External = () => {
  return (
    <div>
      <div className='primary'>hello pooja</div>
      
    </div>
  )
}

export default External
