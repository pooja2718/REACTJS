import React from 'react'

function Clscom() {
  return (
    <div>
      <h1>classs comp</h1>
        

      
    </div>
  )
}

export default Clscom
