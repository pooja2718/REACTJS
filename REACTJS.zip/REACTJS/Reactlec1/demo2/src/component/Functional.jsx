import React from 'react'

function Functional() {
  return (
    <div>
       <h1>funcational commonemet</h1>
      
    </div>
  )
}

export default Functional
