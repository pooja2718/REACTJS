import React from 'react'

const PropEx2 = ({name,age}) => {
  return (
    <div>
      <h1>{name}- {age}</h1>
    </div>
  )
}

export default PropEx2
