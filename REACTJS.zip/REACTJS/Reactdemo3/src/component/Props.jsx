import React from 'react'

const Props = (props) => {
  return (
    <div>
      <h1>Name {props.name}- Country{props.country}</h1>
    </div>
  )
}

export default Props
