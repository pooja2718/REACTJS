
// import Props from './component/Props'
// import PropEx2 from './component/PropEx2'
// import UserStateEx1 from './component/UserStateEx1'
import ConditionalRendering from './component/ConditionalRendering'

function App() {

  return (
    <>
      {/* <Props name="pooja" country="india"/>
      <PropEx2 name="patel" age="20"/>
      <UserStateEx1/> */}
      <ConditionalRendering islogged={true}/>

      
    </>
  )
}

export default App
